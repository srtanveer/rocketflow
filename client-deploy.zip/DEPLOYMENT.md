# Deployment Guide - cPanel Hosting

## Prerequisites

Before deploying to cPanel, ensure you have:
- Access to your cPanel account
- Node.js version 18+ installed on your local machine
- All environment variables ready

## Environment Variables

Create a `.env.production` file with:

```env
NEXT_PUBLIC_ADMIN_API=https://api.beta.rocketflow.biz
CLOUDINARY_URL=cloudinary://918721931624947:K7kuRJYUZlWWiRGncbrwuG1pGro@dogihrsbv
```

## Build Process

### 1. Install Dependencies

```bash
cd client
npm install
```

### 2. Build the Application

```bash
npm run build:cpanel
```

This will create an optimized static export in the `out` directory.

## Deployment Steps

### Option 1: Using File Manager (Recommended for beginners)

1. **Build the project** locally using `npm run build:cpanel`

2. **Compress the output**:
   - Compress the entire `out` folder into a ZIP file

3. **Upload to cPanel**:
   - Log into your cPanel account
   - Navigate to **File Manager**
   - Go to the `public_html` directory (or your domain's root directory)
   - Upload the ZIP file
   - Extract the ZIP file
   - Move all contents from the `out` folder to the root directory

4. **Verify .htaccess**:
   - Ensure the `.htaccess` file is in the root directory
   - If not visible, enable "Show Hidden Files" in File Manager settings

### Option 2: Using FTP/SFTP

1. **Build the project** locally using `npm run build:cpanel`

2. **Connect via FTP**:
   - Use an FTP client like FileZilla, Cyberduck, or WinSCP
   - Connect using your cPanel FTP credentials

3. **Upload files**:
   - Navigate to `public_html` (or your domain's root)
   - Upload all contents from the `out` folder
   - Ensure `.htaccess` is uploaded (enable showing hidden files if needed)

### Option 3: Using cPanel Terminal (Advanced)

1. **Access Terminal** in cPanel

2. **Clone and build**:
   ```bash
   cd public_html
   git clone <your-repo-url> temp
   cd temp/client
   npm install
   npm run build:cpanel
   mv out/* ../../
   cd ../../
   rm -rf temp
   ```

## Post-Deployment

### 1. Test Your Site

Visit your domain and check:
- ✅ Homepage loads correctly
- ✅ Navigation works (all routes)
- ✅ Images display properly
- ✅ Forms function correctly
- ✅ API calls work (blog posts, tutorials, etc.)

### 2. Enable SSL (HTTPS)

1. In cPanel, go to **SSL/TLS Status**
2. Enable AutoSSL for your domain
3. Once SSL is active, uncomment the HTTPS redirect in `.htaccess`:

```apache
# Uncomment these lines in public/.htaccess
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
```

### 3. Configure DNS

Ensure your domain's DNS points to your cPanel server:
- Set A record to your server's IP address
- Set CNAME for www subdomain

## Troubleshooting

### Issue: 404 errors on page refresh

**Solution**: Ensure `.htaccess` is in the root directory and the rewrite rules are active.

### Issue: Images not loading

**Solution**: Check that:
- Images are in the correct path
- File permissions are set to 644 for files, 755 for directories
- Image URLs in the code are correct

### Issue: API calls failing

**Solution**: Verify:
- `NEXT_PUBLIC_ADMIN_API` is correctly set
- The API server is running and accessible
- CORS is configured on the API server

### Issue: Blank white page

**Solution**: Check:
- Browser console for JavaScript errors
- File permissions (should be 644 for files, 755 for folders)
- `.htaccess` is properly configured

## File Structure After Deployment

```
public_html/
├── .htaccess          # Routing and server configuration
├── index.html         # Main entry point
├── 404.html          # Custom 404 page
├── robots.txt        # SEO robots file
├── sitemap.xml       # SEO sitemap
├── _next/            # Next.js static assets
│   └── static/
├── images/           # Static images
└── ...               # Other static assets
```

## Updating Your Site

To deploy updates:

1. Make your changes locally
2. Test thoroughly
3. Run `npm run build:cpanel`
4. Upload only the changed files or the entire `out` folder
5. Clear browser cache to see changes

## Performance Tips

1. **Enable Caching**: The `.htaccess` file already includes browser caching rules
2. **Optimize Images**: Use WebP format where possible
3. **Monitor Performance**: Use tools like Google PageSpeed Insights
4. **CDN**: Consider using a CDN like Cloudflare for better global performance

## Security Checklist

- ✅ SSL certificate enabled
- ✅ Environment variables not exposed in client code
- ✅ Security headers set in `.htaccess`
- ✅ Directory browsing disabled
- ✅ Sensitive files protected

## Need Help?

If you encounter issues:
1. Check cPanel error logs (Metrics → Errors)
2. Review browser console for client-side errors
3. Verify all environment variables are correctly set
4. Ensure Node.js version compatibility

## Automated Deployment (Optional)

For advanced users, you can set up GitHub Actions or similar CI/CD:

1. Push to main branch triggers build
2. Automated FTP upload to cPanel
3. Zero-downtime deployment

See `.github/workflows` directory for examples (to be created if needed).
