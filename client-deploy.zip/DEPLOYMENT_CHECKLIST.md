# Pre-Deployment Checklist

## Before Building

- [ ] All features tested locally
- [ ] No console errors in browser
- [ ] All API endpoints working
- [ ] Environment variables configured in `.env.production`
- [ ] Images optimized and compressed
- [ ] Dependencies up to date (`npm outdated`)
- [ ] Code linted (`npm run lint`)

## Build Process

- [ ] Run `npm install` to ensure all dependencies are installed
- [ ] Run `npm run build:cpanel` successfully
- [ ] Check `out` folder is created with all files
- [ ] Verify `.htaccess` exists in `out` folder

## Upload to cPanel

- [ ] cPanel login credentials ready
- [ ] Backup existing site (if updating)
- [ ] Clear `public_html` directory (or domain root)
- [ ] Upload all files from `out` folder
- [ ] Verify `.htaccess` uploaded (show hidden files)
- [ ] Set file permissions: 644 for files, 755 for folders

## Post-Deployment Testing

### Functionality
- [ ] Homepage loads correctly
- [ ] Navigation menu works
- [ ] All page routes accessible
- [ ] Blog posts load
- [ ] Tutorials load
- [ ] Contact form submits
- [ ] Admin panel accessible (if applicable)

### Performance
- [ ] Page load time acceptable
- [ ] Images load quickly
- [ ] No 404 errors in console
- [ ] JavaScript executes properly
- [ ] CSS styles applied correctly

### SEO & Metadata
- [ ] Page titles correct
- [ ] Meta descriptions present
- [ ] Open Graph tags working
- [ ] `robots.txt` accessible
- [ ] `sitemap.xml` accessible
- [ ] Favicon displays

### Security
- [ ] SSL certificate active (HTTPS)
- [ ] HTTPS redirect working
- [ ] Security headers present (check browser dev tools)
- [ ] No sensitive data exposed
- [ ] Environment variables secure

### Cross-Browser Testing
- [ ] Chrome
- [ ] Firefox
- [ ] Safari
- [ ] Edge
- [ ] Mobile browsers

### Mobile Responsiveness
- [ ] Mobile view renders correctly
- [ ] Touch interactions work
- [ ] No horizontal scrolling
- [ ] Text readable on small screens
- [ ] Images scale properly

## DNS & Domain

- [ ] Domain points to correct server
- [ ] A record configured
- [ ] WWW subdomain working
- [ ] DNS propagation complete

## Monitoring & Maintenance

- [ ] Analytics setup (Google Analytics, etc.)
- [ ] Error monitoring configured
- [ ] Backup schedule established
- [ ] Update plan documented

## Documentation

- [ ] Deployment process documented
- [ ] Troubleshooting guide available
- [ ] Contact information for support
- [ ] Version number/build ID recorded

---

## Emergency Rollback Plan

If something goes wrong:

1. **Immediate**: Restore from backup
2. **Investigate**: Check cPanel error logs
3. **Fix**: Address the issue locally
4. **Rebuild**: Run `npm run build:cpanel` again
5. **Redeploy**: Upload fixed version

---

## Notes

Date deployed: _______________
Deployed by: _______________
Build version: _______________
Issues found: _______________
