# 🚀 Quick Deployment Guide

## Build & Deploy in 3 Steps

### 1️⃣ Build the Project
```bash
cd client
npm install
npm run build:cpanel
```

### 2️⃣ Upload to cPanel
- Go to **File Manager** in cPanel
- Navigate to `public_html`
- Upload & extract the `out` folder contents
- Ensure `.htaccess` is present

### 3️⃣ Enable SSL (Optional but Recommended)
- In cPanel → **SSL/TLS Status** → Enable AutoSSL
- Uncomment HTTPS redirect in `.htaccess`

---

## 📁 What Gets Deployed?

After running `npm run build:cpanel`, the `out` folder contains:
- `index.html` - Main entry point
- `_next/` - Optimized assets (JS, CSS)
- `images/` - Static images
- `.htaccess` - Server configuration
- Other static pages

---

## ✅ Post-Deployment Checklist

- [ ] Homepage loads
- [ ] All routes work (refresh test)
- [ ] Images display correctly
- [ ] API calls function (blog, tutorials)
- [ ] Forms submit properly
- [ ] SSL certificate active
- [ ] DNS configured correctly

---

## 🔧 Common Commands

```bash
# Development
npm run dev

# Production build for cPanel
npm run build:cpanel

# Deploy (same as build:cpanel)
npm run deploy

# Check for errors
npm run lint
```

---

## 🆘 Quick Fixes

**404 on refresh?**
→ Check `.htaccess` is in root directory

**Images not loading?**
→ Verify file permissions (644 for files, 755 for folders)

**API not working?**
→ Check `NEXT_PUBLIC_ADMIN_API` in `.env.production`

**Blank page?**
→ Check browser console & cPanel error logs

---

## 📞 Environment Variables

Make sure these are set in `.env.production`:
```env
NEXT_PUBLIC_ADMIN_API=https://api.beta.rocketflow.biz
CLOUDINARY_URL=cloudinary://...
```

---

For detailed instructions, see `DEPLOYMENT.md`
