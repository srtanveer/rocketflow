"use client"

export default function DashboardLayout({ children }) {
  return children
}
