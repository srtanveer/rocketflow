import { CorporateOfficePage } from '../../components';

export default function CorporateOffice() {
  return <CorporateOfficePage />;
}
