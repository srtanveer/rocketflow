'use client'

import EducationPage from '../../components/EducationPage';

export default function Education() {
  return <EducationPage />;
}