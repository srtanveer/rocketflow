'use client'

import SalonPage from '../../components/SalonPage';

export default function Salon() {
  return <SalonPage />;
}
