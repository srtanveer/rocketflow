import { StudyAbroad } from '../../components';

export default function StudyAbroadPage() {
  return <StudyAbroad />;
  
}