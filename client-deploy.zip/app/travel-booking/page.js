import { TravelBooking } from '../../components';

export default function TravelBookingPage() {
  return <TravelBooking />;
}
