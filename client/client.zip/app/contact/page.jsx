import { ContactPage } from '../../components';

export default function Contact() {
  return <ContactPage />;
}
