import { EcommercePage } from '../../components';

export default function Ecommerce() {
  return <EcommercePage />;
}
