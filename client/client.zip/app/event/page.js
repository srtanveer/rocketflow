import EventPage from '../../components/EventPage'

export default function Event() {
  return <EventPage />
}