import { OrganicProductsPage } from '../../components';

export default function OrganicProducts() {
  return <OrganicProductsPage />;
}
