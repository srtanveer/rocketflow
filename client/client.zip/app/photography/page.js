'use client'

import PhotographyPage from '../../components/PhotographyPage';

export default function Photography() {
  return <PhotographyPage />;
}
